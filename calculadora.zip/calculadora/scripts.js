let displayValue = '';

function appendValue(val) {
    displayValue += val;
    updateDisplay();
}

function appendOperator(operator) {
    if (displayValue !== '' && !isOperator(displayValue.charAt(displayValue.length - 1))) {
        displayValue += operator;
        updateDisplay();
    }
}

function appendDecimal() {
    displayValue += '.';
    updateDisplay();
}

function clearDisplay() {
    displayValue = '';
    updateDisplay();
}
function backspace() {
    displayValue = displayValue.slice(0, -1);
    updateDisplay();
}
function calculate() {
    try {
        let result = eval(displayValue);
        result = Math.round(result * 100) / 100;
        displayValue = result.toString();
        updateDisplay();
    } catch (error) {
        displayValue = 'Error';
        updateDisplay();
    }
}

function updateDisplay() {
    document.getElementById('display').value = displayValue;
}

function isOperator(char) {
    return ['+', '-', '*', '/'].includes(char);
}